<?php
if (!defined('__TYPECHO_ROOT_DIR__')) {
    exit;
}
include 'inc/form.min.php';
include 'inc/header.min.php';
include 'inc/footer.min.php';

/**
 * <strong style="color:#7682fa;font-family: 楷体;">萌卜兔's 美化插件</strong>
 *
 * @package AliceStyle
 * @author <strong style="color:#7682fa;font-family: -webkit-pictograph;">racns</strong>
 * @version <strong style="color:#7682fa;font-family: 楷体;">2.6.0</strong>
 * @update: 2020-3-17
 * @link //racns.com
 */
class AliceStyle_Plugin implements Typecho_Plugin_Interface
{
	
    /**
     * 激活插件方法,如果激活失败,直接抛出异常
     *
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->header = array(__CLASS__, 'header');
        Typecho_Plugin::factory('Widget_Archive')->footer = array(__CLASS__, 'footer');
        
        // 激活后台menu页面接口
        Typecho_Plugin::factory('admin/menu.php')->navBar = array('AliceStyle_Plugin', 'render');
        
        // 激活后台header接口
        Typecho_Plugin::factory('admin/header.php')->header = array('AliceStyle_Plugin', 'A_Header');
        
        // 激活后台footer接口
        Typecho_Plugin::factory('admin/footer.php')->end = array('AliceStyle_Plugin', 'A_Footer');
        
        // 添加路由
        Helper::addRoute("route_AliceStyle","/AliceStyle","AliceStyle_Action",'action');
        return '插件安装成功，请进入设置配置信息！';
        
    }

    /**
     * 禁用插件方法,如果禁用失败,直接抛出异常
     *
     * @static
     * @access public
     * @return void
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate()
    {
    	// 删除路由
    	Helper::removeRoute("route_AliceStyle");
    	return '插件卸载成功了呢';
    }

    /**
     * 获取插件配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config(Typecho_Widget_Helper_Form $form){
    	
		// 在线检查最新版本	参数 '本插件的版本号'
		PluginsForm::updata('20200323');
		
		// 初始化
		PluginsForm::init();
		
		// 测试用的
		PluginsForm::test();
		
        // 动态背景
        $form->addInput(PluginsForm::DynamicBackground(), PluginsForm::GetDBFlie());
        
        // 主题美化
        $form->addInput(PluginsForm::PrettifyStyle());
        
        // 返回顶部
        $form->addInput(PluginsForm::ReturnTop());
        
        // 更新提示
        $form->addInput(PluginsForm::UpdataTips());
        
        // Live2D
        $form->addInput(PluginsForm::Live2D());
        
        // 图灵机器人APIKEY
        $form->addInput(PluginsForm::APIKEY());
        
        // 鼠标样式
        $form->addInput(PluginsForm::MouseStyle());
        
        // 遮罩特效
        $form->addInput(PluginsForm::Mask());
        
        // 夜间模式
        $form->addInput(PluginsForm::NightMode());
        
        // 后台美化
        $form->addInput(PluginsForm::AliceStyleAdmin());
        
        // 登录背景
        $form->addInput(PluginsForm::LoginBg());
        
        // 登录框美化
        $form->addInput(PluginsForm::LoginCard());
        
    }
    
    /**
     * 个人用户的配置面板
     *
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    /**
     * 插件实现方法
     *
     * @access public
     * @return void
     */
    public static function render(){
    	
    	// 更新提示	参数 '本插件的版本号'
		PluginsHead::UpdataTips('20200323');
		
    }

    /**
     *为header添加css文件
     * @return void
     */
    public static function header(){
    	
        // 主题美化
        PluginsHead::PrettifyStyle();

        // 返回顶部开关
        PluginsHead::ReturnTop();
        
        // Live2D
		PluginsHead::Live2D();
		
		// 顶部跑马灯特效
		PluginsHead::TopLamp();
		
		// 夜间模式	参数 '开始时间','结束时间' 24小时整点格式
		PluginsHead::NightMode('23','5');
    }

    /**
     *为footer添加js文件
     * @return void
     */
    public static function footer(){
    	
        // 动态背景
        PluginsFooter::DynamicBackground();
        
        // 主题美化
        PluginsFooter::PrettifyStyle();
        
        // 返回顶部
        PluginsFooter::ReturnTop();
		
		// Live2D
		PluginsFooter::Live2D();
		
		// 鼠标样式
		PluginsFooter::MouseStyle();
        
		// 遮罩特效
		PluginsFooter::Mask();
		
		// 输出log
		PluginsFooter::TagLog();
    }
    
    /**
     *为后台header添加css文件
     * @return void
     */
    public static function A_Header(){
    	
    	// 后台美化
    	PluginsHead::AliceStyleAdmin();
    	
    	// 登录壁纸
    	PluginsHead::LoginBg();
    	
    	// 登录框美化
    	PluginsHead::LoginCard();
    }
    
    /**
     *为后台footer添加js文件
     * @return void
     */
     public static function A_Footer(){
     	
     	// 后台美化
     	PluginsFooter::AliceStyleAdmin();
     }
    
}
